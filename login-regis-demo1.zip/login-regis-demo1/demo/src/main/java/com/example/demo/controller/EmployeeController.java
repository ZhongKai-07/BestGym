package com.example.demo.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.example.demo.domain.Activity;
import com.example.demo.domain.Employee;
import com.example.demo.domain.Facility;
import com.example.demo.domain.User;
import com.example.demo.service.ActivityService;
import com.example.demo.service.EmployeeService;
import com.example.demo.service.FacilityService;
import com.example.demo.service.UserService;
import com.example.demo.utils.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import org.springframework.stereotype.Controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.List;

/**
 * <p>
 * 职工 前端控制器
 * </p>
 *
 * @author 
 * @since 2022-04-13
 */
@RestController
@RequestMapping("/employee")
public class EmployeeController {
    @Resource
    private EmployeeService employeeService;
    @Autowired
    private UserService userService;
    @Autowired
    private FacilityService facilityService;
    @Autowired
    private ActivityService activityService;


    @GetMapping("/showAllEmployee")
    public Result showAllEmployee() {
        List<Employee> e_list = employeeService.list();

        if (e_list == null) {
            return Result.error("-1", " Employee list find Failed.");
        }

        return Result.success(e_list, "Find Success");
    }

    @PostMapping("/findUser")
    public Result findUser(@RequestParam(value = "username") String username) {
        List<User> u_list;
        // 返回所有y
        if ("".equals(username)) {
            u_list = userService.list();
        } else {
            u_list = userService.list(new QueryWrapper<User>().eq("username", username));
        }
        if (u_list == null) {
            return Result.error("-1", "The user is not exist!");
        }

        return Result.success(u_list, "Find Success!");
    }

    /**
     * 对于场地的操作
     **/
    // 查看所有器械信息
    @GetMapping("/showFacility")
    public Result showFacility() {
        List<Facility> f_List = facilityService.list();

        if (f_List == null) {
            return Result.error("-1", "Find Failed");
        }

        return Result.success(f_List, "Find Success!");
    }


    // 查看场地的活动
    @GetMapping("/showActivity")
    public Result showActivity(@RequestParam String type) {
        Facility facility = facilityService.getOne(new QueryWrapper<Facility>().eq("facility_type", type));
        Integer facility_id = facility.getId();
        List<Activity> act_List = activityService.list(new QueryWrapper<Activity>().
                eq("activity_to_which_facility", facility_id));
        if(act_List==null) return Result.error("-1", "failed");

        return Result.success(act_List, "成功返回对应场地的活动");
    }
}



