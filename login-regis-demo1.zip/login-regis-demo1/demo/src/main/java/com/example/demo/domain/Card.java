package com.example.demo.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 会员卡
 * </p>
 *
 * @author 
 * @since 2022-04-09
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class Card extends Model<Card> {

    private static final long serialVersionUID = 1L;

      @TableId(value = "number", type = IdType.AUTO)
    private Integer number;

    private Integer userid;


    @Override
    protected Serializable pkVal() {
        return this.number;
    }

}
