package com.example.demo.dao;

import com.example.demo.domain.Employee;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 职工 Mapper 接口
 * </p>
 *
 * @author 
 * @since 2022-04-13
 */
public interface EmployeeMapper extends BaseMapper<Employee> {

}
