package com.example.demo.dao;

import com.example.demo.domain.Card;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 会员卡 Mapper 接口
 * </p>
 *
 * @author 
 * @since 2022-04-09
 */
public interface CardMapper extends BaseMapper<Card> {

}
