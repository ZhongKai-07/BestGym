package com.example.demo.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 会员卡 前端控制器
 * </p>
 *
 * @author 
 * @since 2022-04-09
 */
@RestController
@RequestMapping("/card")
public class CardController {

}

