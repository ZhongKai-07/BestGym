package com.example.demo.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.example.demo.domain.Employee;
import com.example.demo.domain.User;
import com.example.demo.service.EmployeeService;
import com.example.demo.service.UserService;
import com.example.demo.utils.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
 * <p>
 * 鐢ㄦ埛 前端控制器
 * </p>
 *
 * @author 
 * @since 2022-04-08
 */
@RestController
@RequestMapping("/user")
public class UserController {
    @Resource
    private UserService userService;
    @Autowired
    private EmployeeService employeeService;

    @PostMapping("/login")
    public Result login(@RequestBody User user){


        Employee e = employeeService.getOne(new QueryWrapper<Employee>().eq("username", user.getUsername()));
        User u=userService.getOne(new QueryWrapper<User>().eq("username", user.getUsername()));


        if(u!=null && !user.getPassword().equals(u.getPassword())){
            return Result.error("-1","用户登录，账号或密码不正确");
        }
        if(e!=null && !user.getPassword().equals(e.getPassword())){
            return Result.error("-1","员工登录，账号或密码不正确");
        }


        if(u == null && e != null) {
            return Result.success(e,"验证通过， 员工登录");
        }
        else if(u != null && e == null) return Result.success(u, "验证通过， 用户登录");
        else return Result.error("-1", "用户不存在");
    }


    @PostMapping("/add")
    public Result regist(@RequestBody User user){

        User us=userService.getOne(new QueryWrapper<User>().eq("username", user.getUsername()));
        if(us!=null){
            return  Result.error("-1","This username exists!");
        }
        User us2 = userService.getOne(new QueryWrapper<User>().eq("email", user.getEmail()));
        if (us2 != null) {
            return Result.error("-1", "This email exists!");
        }
        boolean u=userService.save(user);

        if(u){
            return  Result.success();
        }else{
            return  Result.error("-1","失败");
        }
    }


    @PostMapping("/modify")
    public Result modify(@RequestBody User user){
//        User us=userService.getOne(new QueryWrapper<User>().eq("username", user.getUsername()));
//        if(us!=null){
//            return  Result.error("-1","This username exists!");
//        }
//        User us2 = userService.getOne(new QueryWrapper<User>().eq("email", user.getEmail()));
//        if (us2 != null) {
//            return Result.error("-1", "This email exists!");
//        }
//        boolean u=userService.save(user);

        User us = userService.getOne(new QueryWrapper<User>().eq("username", user.getUsername()));
        UpdateWrapper<User> updateWrapper = new UpdateWrapper<>();

        updateWrapper.set("password", user.getPassword());
        updateWrapper.set("email", user.getEmail());
        updateWrapper.set("phoneNumber", user.getPhoneNumber());
        boolean u = userService.update(us, updateWrapper);

        if(u){
            return  Result.success();
        }else{
            return  Result.error("-1","失败");
        }
    }

    @GetMapping("/getUser")
    public Result test(){
        return  Result.success(userService.getUserOne(1));
    }
}

