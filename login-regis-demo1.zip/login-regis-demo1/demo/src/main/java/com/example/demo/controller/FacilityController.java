package com.example.demo.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.example.demo.domain.Facility;
import com.example.demo.service.FacilityService;
import com.example.demo.utils.Result;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

/**
 * <p>
 *  前端控制器
 *  Facility
 * </p>
 *
 * @author 
 * @since 2022-04-13
 */
@RestController
@RequestMapping("/facility")
public class FacilityController {
    @Resource
    private FacilityService facilityService;

    // 返回所有器械信息
    @GetMapping("/findAllFacility")
    public Result findAllFacility(){
        List<Facility> f_List = facilityService.list();

        if(f_List==null){
            return  Result.error("-1", "Find Failed");
        }

        return Result.success(f_List, "Find Success!");
    }

    // 传参数：facility的type，返回指定facility
    @GetMapping("/detail")
    public Result detail(@RequestParam String type){
        Facility fs = facilityService.getOne(new QueryWrapper<Facility>().eq("facility_type", type));
        if(fs == null){
            return Result.error("-1", "Failed");
        }

        return Result.success(fs, "Find Success!");
    }
}

